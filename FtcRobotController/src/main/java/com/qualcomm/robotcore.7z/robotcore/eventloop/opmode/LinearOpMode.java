//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.qualcomm.robotcore.eventloop.opmode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.util.RobotLog;

public abstract class LinearOpMode extends OpMode {
    private LinearOpMode.a a = null;
    private Thread b = null;
    private volatile boolean c = false;

    public LinearOpMode() {
    }

    public abstract void runOpMode() throws InterruptedException;

    public synchronized void waitForStart() throws InterruptedException {
        while(!this.c) {
            synchronized(this) {
                this.wait();
            }
        }

    }

    public void waitOneHardwareCycle() throws InterruptedException {
        synchronized(this) {
            this.wait();
        }
    }

    public void sleep(long milliseconds) throws InterruptedException {
        Thread.sleep(milliseconds);
    }

    public boolean opModeIsActive() {
        return this.c;
    }

    public final void init() {
        this.a = new LinearOpMode.a(this);
        this.b = new Thread(this.a);
        this.b.start();
    }

    public final void start() {
        this.c = true;
        synchronized(this) {
            this.notifyAll();
        }
    }

    public final void loop() {
        if(this.a.a()) {
            throw this.a.b();
        } else {
            synchronized(this) {
                this.notifyAll();
            }
        }
    }

    public final void stop() {
        this.c = false;
        if(!this.a.c()) {
            this.b.interrupt();
        }

    }

    private static class a implements Runnable {
        private RuntimeException a = null;
        private boolean b = false;
        private final LinearOpMode c;

        public a(LinearOpMode var1) {
            this.c = var1;
        }

        public void run() {
            this.a = null;
            this.b = false;

            try {
                this.c.runOpMode();
            } catch (InterruptedException var6) {
                RobotLog.d("LinearOpMode received an Interrupted Exception; shutting down this linear op mode");
            } catch (RuntimeException var7) {
                this.a = var7;
            } finally {
                this.b = true;
            }

        }

        public boolean a() {
            return this.a != null;
        }

        public RuntimeException b() {
            return this.a;
        }

        public boolean c() {
            return this.b;
        }
    }
}

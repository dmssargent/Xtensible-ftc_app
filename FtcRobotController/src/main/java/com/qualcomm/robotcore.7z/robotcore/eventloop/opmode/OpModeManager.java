package com.qualcomm.robotcore.eventloop.opmode;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorController;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.LightSensor;
import com.qualcomm.robotcore.hardware.ServoController;
import com.qualcomm.robotcore.hardware.DcMotorController.DeviceMode;
import com.qualcomm.robotcore.hardware.DcMotorController.RunMode;
import com.qualcomm.robotcore.util.RobotLog;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class OpModeManager {
    public static final String DEFAULT_OP_MODE_NAME = "Stop Robot";
    public static final OpMode DEFAULT_OP_MODE = new OpModeManager.StopRobotOpMode();
    private Map<String, Class> opModeRegisterClassMap = new LinkedHashMap<>();
    private Map<String, OpMode> opModeRegisterOpModeMap = new LinkedHashMap<>();
    private String defaultOpModeName = "Stop Robot";
    private OpMode defaultOpMode;
    private OpMode currentOpMode;
    private String currentOpModeName;
    private HardwareMap g;
    private HardwareMap h;
    private boolean i;
    private boolean resume;
    private boolean k;

    public OpModeManager(HardwareMap hardwareMap)  {
        this.defaultOpMode = DEFAULT_OP_MODE;
        this.currentOpMode = DEFAULT_OP_MODE;
        this.currentOpModeName = DEFAULT_OP_MODE_NAME;
        this.h = new HardwareMap();
        this.i = false;
        this.resume = false;
        this.k = false;
        this.g = hardwareMap;
        this.register("Stop Robot", StopRobotOpMode.class);
        this.switchOpModes("Stop Robot");
    }

    public void registerOpModes(OpModeRegister register) {
        register.register(this);
    }

    public void setHardwareMap(HardwareMap hardwareMap) {
        this.g = hardwareMap;
    }

    public HardwareMap getHardwareMap() {
        return this.g;
    }

    public Set<String> getOpModes() {
        HashSet<String> opModeLinkedHashSet = new LinkedHashSet<>();
        opModeLinkedHashSet.addAll(this.opModeRegisterClassMap.keySet());
        opModeLinkedHashSet.addAll(this.opModeRegisterOpModeMap.keySet());
        return opModeLinkedHashSet;
    }

    public String getActiveOpModeName() {
        return this.defaultOpModeName;
    }

    public OpMode getActiveOpMode() {
        return this.defaultOpMode;
    }

    public void resumeOpMode() {
        this.defaultOpModeName = this.currentOpModeName;
        this.resume = true;
    }

    public void pauseOpMode(String name) {
        if(!name.equals("Stop Robot")) {
            this.currentOpModeName = name;
            this.currentOpMode = this.defaultOpMode;
            this.k = true;
            this.defaultOpModeName = "Stop Robot";
            this.i = true;
        }
    }

    public void cancelResume() {
        this.currentOpMode = DEFAULT_OP_MODE;
        this.currentOpModeName = "Stop Robot";
        this.k = false;
        this.resume = false;
    }

    public void switchOpModes(String name) {
        this.defaultOpModeName = name;
        this.i = true;
    }

    public void startActiveOpMode() {
        if(!this.resume) {
            this.defaultOpMode.hardwareMap = this.g;
            this.defaultOpMode.init();
            this.defaultOpMode.resetStartTime();
            this.defaultOpMode.start();
        }
    }

    public void stopActiveOpMode() {
        this.defaultOpMode.stop();
    }

    public void runActiveOpMode(Gamepad[] gamepads) {
        this.defaultOpMode.time = this.defaultOpMode.getRuntime();
        this.defaultOpMode.gamepad1 = gamepads[0];
        this.defaultOpMode.gamepad2 = gamepads[1];
        if(this.resume) {
            this.resume();
        }

        if(this.i) {
            this.switchOpMode();
        }

        this.defaultOpMode.loop();
    }

    public void logOpModes() {
        int var1 = this.opModeRegisterClassMap.size() + this.opModeRegisterOpModeMap.size();
        RobotLog.i("There are " + var1 + " Op Modes");
        Iterator var2 = this.opModeRegisterClassMap.entrySet().iterator();

        Entry var3;
        while(var2.hasNext()) {
            var3 = (Entry)var2.next();
            RobotLog.i("   Op Mode: " + (String)var3.getKey());
        }

        var2 = this.opModeRegisterOpModeMap.entrySet().iterator();

        while(var2.hasNext()) {
            var3 = (Entry)var2.next();
            RobotLog.i("   Op Mode: " + (String)var3.getKey());
        }

    }

    public void register(String name, Class opMode) {
        if(this.resume(name)) {
            throw new IllegalArgumentException("Cannot register the same op mode name twice");
        } else {
            this.opModeRegisterClassMap.put(name, opMode);
        }
    }

    public void register(String name, OpMode opMode) {
        if(this.resume(name)) {
            throw new IllegalArgumentException("Cannot register the same op mode name twice");
        } else {
            this.opModeRegisterOpModeMap.put(name, opMode);
        }
    }

    private void resume() {
        RobotLog.i("Attempting to resume op mode " + this.defaultOpModeName);
        this.defaultOpModeName = this.currentOpModeName;
        this.defaultOpMode = this.currentOpMode;
        this.i = false;
        this.k = false;
        this.resume = false;
        this.currentOpModeName = "Stop Robot";
        this.currentOpMode = DEFAULT_OP_MODE;
    }

    private void switchOpMode() {
        RobotLog.i("Attempting to switch to op mode " + this.defaultOpModeName);
        if(!this.k) {
            this.stopActiveOpMode();
        }

        try {
            if(this.opModeRegisterOpModeMap.containsKey(this.defaultOpModeName)) {
                this.defaultOpMode = this.opModeRegisterOpModeMap.get(this.defaultOpModeName);
            } else {
                this.defaultOpMode = (OpMode)(this.opModeRegisterClassMap.get(this.defaultOpModeName)).newInstance();
            }
        } catch (InstantiationException var2) {
            this.resume((Exception) var2);
        } catch (IllegalAccessException var3) {
            this.resume((Exception) var3);
        }

        this.startActiveOpMode();
        this.i = false;
    }

    private boolean resume(String var1) {
        return this.getOpModes().contains(var1);
    }

    private void resume(Exception var1) {
        RobotLog.e("Unable to start op mode " + this.defaultOpModeName);
        RobotLog.logStacktrace(var1);
        this.defaultOpModeName = "Stop Robot";
        this.defaultOpMode = DEFAULT_OP_MODE;
    }

    private static class StopRobotOpMode extends OpMode {
        public void init() {
            this.stopMode();
        }

        public void start() {
            this.stopMode();
        }

        public void loop() {
            this.stopMode();
            this.telemetry.addData("Status", "Robot is stopped");
        }

        public void stop() {
        }

        private void stopMode() {
            Iterator iterator = this.hardwareMap.servoController.iterator();
            while(iterator.hasNext()) {
                ServoController servo = (ServoController)iterator.next();
                servo.pwmDisable();
            }

            iterator = this.hardwareMap.dcMotorController.iterator();
            while(iterator.hasNext()) {
                DcMotorController dcMotorController = (DcMotorController)iterator.next();
                dcMotorController.setMotorControllerDeviceMode(DeviceMode.WRITE_ONLY);
            }

            iterator = this.hardwareMap.dcMotor.iterator();
            while(iterator.hasNext()) {
                DcMotor var4 = (DcMotor)iterator.next();
                var4.setPowerFloat();
                var4.setChannelMode(RunMode.RUN_WITHOUT_ENCODERS);
            }

            iterator = this.hardwareMap.lightSensor.iterator();
            while(iterator.hasNext()) {
                LightSensor var5 = (LightSensor)iterator.next();
                var5.enableLed(false);
            }

        }
    }
}

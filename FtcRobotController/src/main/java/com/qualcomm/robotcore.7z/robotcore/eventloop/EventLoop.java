//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.qualcomm.robotcore.eventloop;

import com.qualcomm.robotcore.eventloop.EventLoopManager;
import com.qualcomm.robotcore.eventloop.opmode.OpModeManager;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.robocol.Command;

public interface EventLoop {
    void init(EventLoopManager var1) throws RobotCoreException, InterruptedException;

    void loop() throws RobotCoreException, InterruptedException;

    void teardown() throws RobotCoreException, InterruptedException;

    void processCommand(Command var1);

    OpModeManager getOpModeManager();
}

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.qualcomm.robotcore.exception;

import com.qualcomm.robotcore.exception.RobotCoreException;

public class RobotCoreNonResponsiveException extends RobotCoreException {
    public RobotCoreNonResponsiveException(String message) {
        super(message);
    }
}

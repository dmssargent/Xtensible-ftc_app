//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.qualcomm.robotcore.eventloop.opmode;

import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.robocol.Telemetry;
import java.util.concurrent.TimeUnit;

public abstract class OpMode {
    public Gamepad gamepad1 = new Gamepad();
    public Gamepad gamepad2 = new Gamepad();
    public Telemetry telemetry = new Telemetry();
    public HardwareMap hardwareMap = new HardwareMap();
    public double time = 0.0D;
    private long a = 0L;

    public OpMode() {
        this.a = System.nanoTime();
    }

    public abstract void init();

    public void start() {
    }

    public abstract void loop();

    public void stop() {
    }

    public double getRuntime() {
        double var1 = (double)TimeUnit.SECONDS.toNanos(1L);
        return (double)(System.nanoTime() - this.a) / var1;
    }

    public void resetStartTime() {
        this.a = System.nanoTime();
    }
}

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.qualcomm.robotcore.eventloop;

import com.qualcomm.robotcore.exception.RobotCoreException;

public interface SyncdDevice {
    void blockUntilReady() throws RobotCoreException, InterruptedException;

    void startBlockingWork();
}
